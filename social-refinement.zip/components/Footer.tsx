
import React, { useState } from 'react';
import { AppConfig } from '../config';
import { XIcon } from './Icons';

export const Footer: React.FC = () => {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  
  // Estados para os Modais
  const [showPrivacy, setShowPrivacy] = useState(false);
  const [showTerms, setShowTerms] = useState(false);

  // Lógica para envio via FormSubmit (Backup se não tiver Mailchimp)
  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setLoading(true);

    try {
      const response = await fetch(`https://formsubmit.co/ajax/${AppConfig.formEmail}`, {
        method: "POST",
        headers: { 
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          email: email,
          _subject: "Novo Assinante: Newsletter Social Refinement",
          message: "Este usuário deseja receber novidades via newsletter.",
          _template: "table"
        })
      });

      if (response.ok) {
        setSuccess(true);
        setEmail('');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <footer className="bg-slate-50 border-t border-slate-200 pt-16 pb-8 relative z-50">
      <div className="max-w-6xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-1">
            <div className="font-bold text-slate-900 text-lg mb-4">{AppConfig.companyName}</div>
            <p className="text-slate-500 text-sm leading-relaxed">
              Design estratégico para quem não pode se dar ao luxo de parecer amador.
            </p>
          </div>
          
          <div>
            <h4 className="font-semibold text-slate-900 mb-4">Menu</h4>
            <ul className="space-y-2 text-sm text-slate-500">
              <li><a href="#home" className="hover:text-slate-900 transition-colors">Home</a></li>
              <li><a href="#servicos" className="hover:text-slate-900 transition-colors">Serviços</a></li>
              <li><a href="#cases" className="hover:text-slate-900 transition-colors">Cases</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-slate-900 mb-4">Legal</h4>
            <ul className="space-y-2 text-sm text-slate-500">
              <li>
                <button onClick={() => setShowPrivacy(true)} className="hover:text-slate-900 transition-colors text-left">
                  Política de Privacidade
                </button>
              </li>
              <li>
                <button onClick={() => setShowTerms(true)} className="hover:text-slate-900 transition-colors text-left">
                  Termos de Uso
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-slate-900 mb-4">Assine a newsletter</h4>
            
            {success ? (
              <div className="p-3 bg-green-100 text-green-700 text-sm rounded-md border border-green-200 animate-in fade-in">
                Inscrito com sucesso! Obrigado.
              </div>
            ) : (
              /* Se tiver config do Mailchimp, usa form HTML nativo. Se não, usa o FormSubmit AJAX */
              AppConfig.newsletterAction ? (
                <form 
                  action={AppConfig.newsletterAction} 
                  method="POST" 
                  target="_blank" 
                  className="flex gap-2"
                >
                  <input 
                    type="email" 
                    name="EMAIL" // Nome obrigatório para o Mailchimp
                    required
                    placeholder="Seu email" 
                    className="bg-white border border-slate-200 rounded-md px-3 py-2 text-sm w-full focus:outline-none focus:border-slate-400 transition-colors"
                  />
                  <button 
                    type="submit" 
                    className="bg-slate-900 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-slate-800 transition-colors whitespace-nowrap"
                  >
                    Inscrever
                  </button>
                </form>
              ) : (
                <form onSubmit={handleFormSubmit} className="flex gap-2">
                  <input 
                    type="email" 
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Seu email" 
                    disabled={loading}
                    className="bg-white border border-slate-200 rounded-md px-3 py-2 text-sm w-full focus:outline-none focus:border-slate-400 disabled:opacity-50 transition-colors"
                  />
                  <button 
                    type="submit" 
                    disabled={loading}
                    className="bg-slate-900 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-slate-800 disabled:opacity-70 disabled:cursor-wait transition-colors whitespace-nowrap"
                  >
                    {loading ? '...' : 'Inscrever'}
                  </button>
                </form>
              )
            )}
            <p className="mt-2 text-xs text-slate-400">Receba insights sobre posicionamento digital.</p>
          </div>
        </div>

        <div className="border-t border-slate-200 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-xs text-slate-400">
            © {AppConfig.year} {AppConfig.companyName}. Todos os direitos reservados.
          </div>
          <div className="text-xs text-slate-400">
            {AppConfig.contact.location}
          </div>
        </div>
      </div>

      {/* MODAL: POLÍTICA DE PRIVACIDADE */}
      {showPrivacy && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[80vh] overflow-y-auto shadow-2xl flex flex-col">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center sticky top-0 bg-white z-10">
              <h3 className="text-xl font-bold text-slate-900">Política de Privacidade</h3>
              <button onClick={() => setShowPrivacy(false)} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                <XIcon className="w-5 h-5 text-slate-500" />
              </button>
            </div>
            <div className="p-6 text-slate-600 text-sm space-y-4">
              <p>Esta Política de Privacidade descreve como a {AppConfig.companyName} coleta, usa e protege suas informações.</p>
              <h4 className="font-bold text-slate-900">1. Coleta de Dados</h4>
              <p>Coletamos informações que você nos fornece diretamente, como nome, e-mail e telefone ao preencher nossos formulários.</p>
              <h4 className="font-bold text-slate-900">2. Uso das Informações</h4>
              <p>Usamos suas informações para fornecer nossos serviços, responder às suas solicitações e enviar comunicações de marketing (caso tenha optado).</p>
              <h4 className="font-bold text-slate-900">3. Proteção</h4>
              <p>Implementamos medidas de segurança para proteger seus dados contra acesso não autorizado.</p>
            </div>
            <div className="p-6 border-t border-slate-100 bg-slate-50 sticky bottom-0">
              <button onClick={() => setShowPrivacy(false)} className="w-full py-3 bg-slate-900 text-white rounded-xl font-medium hover:bg-slate-800">Entendi</button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: TERMOS DE USO */}
      {showTerms && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[80vh] overflow-y-auto shadow-2xl flex flex-col">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center sticky top-0 bg-white z-10">
              <h3 className="text-xl font-bold text-slate-900">Termos de Uso</h3>
              <button onClick={() => setShowTerms(false)} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                <XIcon className="w-5 h-5 text-slate-500" />
              </button>
            </div>
            <div className="p-6 text-slate-600 text-sm space-y-4">
              <p>Bem-vindo à {AppConfig.companyName}. Ao acessar nosso site, você concorda com estes termos.</p>
              <h4 className="font-bold text-slate-900">1. Serviços</h4>
              <p>Fornecemos serviços de design e consultoria digital. Os detalhes específicos de cada serviço são descritos em nossas propostas comerciais.</p>
              <h4 className="font-bold text-slate-900">2. Propriedade Intelectual</h4>
              <p>Todo o conteúdo deste site (textos, imagens, logotipos) é propriedade da {AppConfig.companyName} e não pode ser reproduzido sem permissão.</p>
            </div>
            <div className="p-6 border-t border-slate-100 bg-slate-50 sticky bottom-0">
              <button onClick={() => setShowTerms(false)} className="w-full py-3 bg-slate-900 text-white rounded-xl font-medium hover:bg-slate-800">Concordo</button>
            </div>
          </div>
        </div>
      )}
    </footer>
  );
};
