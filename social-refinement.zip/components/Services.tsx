import React from 'react';
import { LayoutIcon, FeatherIcon } from './Icons';
import { ServiceItem } from '../types';

export const Services: React.FC = () => {
  const services: ServiceItem[] = [
    { title: 'Mini-site para Bio', desc: 'Uma página centralizadora, rápida e otimizada para converter seguidores em clientes no WhatsApp.', icon: <LayoutIcon className="w-6 h-6" /> },
    { title: 'Identidade Visual', desc: 'Criação de paleta de cores, tipografia e elementos visuais que transmitem sofisticação.', icon: <FeatherIcon className="w-6 h-6" /> },
    { title: 'Templates Editáveis', desc: 'Arquivos Canva organizados para que sua equipe mantenha o padrão visual sem esforço.', icon: <LayoutIcon className="w-6 h-6" /> },
    { title: 'Landing Pages', desc: 'Páginas de alta conversão para lançamentos, captura de leads ou venda de serviços high-ticket.', icon: <LayoutIcon className="w-6 h-6" /> },
    { title: 'Cartão Digital', desc: 'Apresentação moderna e interativa para networking presencial e digital.', icon: <FeatherIcon className="w-6 h-6" /> },
    { title: 'Consultoria de Imagem', desc: 'Análise completa do perfil para eliminar ruídos de comunicação que afastam clientes.', icon: <FeatherIcon className="w-6 h-6" /> }
  ];

  return (
    <section id="servicos" className="py-20 bg-slate-50 border-y border-slate-200">
      <div className="max-w-6xl mx-auto px-6">
        <div className="max-w-2xl">
          <h2 className="text-3xl font-bold text-slate-900">O que entregamos</h2>
          <p className="mt-4 text-slate-600">
            Não vendemos apenas design. Vendemos a percepção de valor que permite você cobrar mais pelo seu trabalho.
          </p>
        </div>

        <div className="mt-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((s) => (
            <article 
              key={s.title} 
              className="group bg-white p-8 rounded-2xl border border-slate-200 hover:border-slate-300 hover:shadow-xl transition-all duration-300 hover:-translate-y-2"
            >
              <div className="w-12 h-12 rounded-lg bg-slate-50 flex items-center justify-center text-slate-700 group-hover:bg-slate-900 group-hover:text-white transition-colors duration-300 mb-6">
                {s.icon}
              </div>
              <h3 className="text-lg font-bold text-slate-900">{s.title}</h3>
              <p className="mt-3 text-sm text-slate-500 leading-relaxed">{s.desc}</p>
              <div className="mt-6 pt-6 border-t border-slate-100 flex items-center text-sm font-semibold text-slate-900 opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-300">
                Saiba mais <span className="ml-2">→</span>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};