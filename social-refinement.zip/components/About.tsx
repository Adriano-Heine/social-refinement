
import React from 'react';
import { AppConfig } from '../config';

export const About: React.FC = () => {
  return (
    <section id="sobre" className="pt-8 pb-24 bg-white overflow-hidden">
      <div className="max-w-6xl mx-auto px-6">
        <div className="flex flex-col lg:flex-row items-center gap-16 lg:gap-20">
          
          {/* Lado da Imagem com Efeito Premium */}
          <div className="lg:w-1/2 w-full relative group perspective-1000">
            
            {/* 1. Elemento Decorativo de Fundo (Grid de Pontos) */}
            <div className="absolute -top-12 -left-12 w-48 h-48 bg-[radial-gradient(#cbd5e1_2px,transparent_2px)] [background-size:16px_16px] opacity-30 z-0 pointer-events-none"></div>

            {/* 2. Glow Atmosférico (Respira atrás da imagem) */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[110%] h-[110%] bg-gradient-to-tr from-slate-200 to-slate-50 rounded-full blur-3xl opacity-60 animate-pulse -z-10"></div>
            
            {/* 3. Container da Imagem Principal */}
            <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-slate-100 transform transition-all duration-700 group-hover:scale-[1.02] group-hover:shadow-[0_20px_50px_-12px_rgba(0,0,0,0.1)] z-10">
              <div className="absolute inset-0 bg-slate-900/0 group-hover:bg-slate-900/5 transition-colors duration-500 z-20"></div>
              <img 
                src={AppConfig.images.about} 
                alt="Social Refinement Office" 
                className="w-full h-auto object-cover transform transition-transform duration-700 group-hover:scale-105"
              />
              
              {/* Efeito de Brilho (Shine) ao passar o mouse */}
              <div className="absolute inset-0 bg-gradient-to-tr from-white/20 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 z-30 pointer-events-none"></div>
            </div>

            {/* 4. Badge Flutuante (Estilo Stripe/Apple) */}
            <div className="absolute -bottom-6 -right-6 lg:-right-8 bg-white/90 backdrop-blur-md p-4 pr-6 rounded-xl shadow-[0_8px_30px_rgb(0,0,0,0.12)] border border-white/50 animate-float-delayed z-40 flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-slate-900 flex items-center justify-center text-white font-serif italic text-lg shadow-lg">
                SR
              </div>
              <div>
                <div className="text-xs font-bold text-slate-900 uppercase tracking-wider">Social Refinement</div>
                <div className="text-[10px] text-slate-500 font-medium mt-0.5">Established {AppConfig.year}</div>
              </div>
            </div>

          </div>
          
          {/* Lado do Texto */}
          <div className="lg:w-1/2">
            <div className="inline-block px-4 py-2 bg-slate-50 border border-slate-200 text-slate-800 rounded-full text-xs font-extrabold uppercase tracking-widest mb-6 shadow-sm">
              Nossa Filosofia
            </div>
            <h2 className="text-4xl lg:text-5xl font-bold text-slate-900 leading-tight">
              A estética é uma <br/>
              <span className="text-slate-400">linguagem silenciosa.</span>
            </h2>
            
            <div className="w-20 h-1.5 bg-slate-900 mt-8 mb-10 rounded-full"></div>
            
            <p className="text-lg text-slate-600 leading-relaxed mb-6 font-light">
              Antes de você dizer uma única palavra, sua imagem já comunicou sua competência, seu preço e sua autoridade. O design não é apenas "deixar bonito", é sobre <strong className="text-slate-900 font-semibold">controle de percepção</strong>.
            </p>
            
            <p className="text-base text-slate-500 leading-relaxed mb-10">
              A {AppConfig.companyName} nasceu para preencher a lacuna entre excelentes profissionais e uma presença digital amadora. Somos um hub de designers, estrategistas e copywriters obcecados pelo detalhe invisível que gera confiança.
            </p>

            <div className="grid grid-cols-2 gap-8 border-t border-slate-100 pt-8">
              <div className="group">
                <div className="text-4xl font-bold text-slate-900 mb-1 group-hover:text-slate-700 transition-colors">4+</div>
                <div className="text-xs font-semibold uppercase tracking-wide text-slate-400">Anos de Mercado</div>
              </div>
              <div className="group">
                <div className="text-4xl font-bold text-slate-900 mb-1 group-hover:text-slate-700 transition-colors">100%</div>
                <div className="text-xs font-semibold uppercase tracking-wide text-slate-400">Foco em High-Ticket</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
