
import React from 'react';
import { AppConfig } from '../config';

export const Cases: React.FC = () => {
  return (
    <section id="cases" className="pt-24 pb-8 bg-white">
      <div className="max-w-6xl mx-auto px-6">
        <h2 className="text-3xl font-bold text-slate-900 mb-2">Transformações Reais</h2>
        <p className="text-slate-500 mb-12">Veja como elevamos o padrão visual de outros profissionais.</p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {AppConfig.images.cases.map((item, index) => (
            <div key={index} className="group cursor-pointer">
              <div className="relative overflow-hidden rounded-xl bg-slate-100 aspect-[4/3] mb-5 border border-slate-200">
                <img 
                  src={item.url} 
                  alt={`Case Study ${index + 1}`} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-slate-900/0 group-hover:bg-slate-900/10 transition-colors duration-300"></div>
              </div>
              <div className="flex items-center gap-2 mb-2">
                <span className="px-2 py-1 bg-slate-100 text-slate-600 text-[10px] uppercase font-bold rounded-md">{item.category}</span>
                <span className="text-slate-400 text-xs">•</span>
                <span className="text-slate-500 text-xs">Case de Sucesso</span>
              </div>
              <h3 className="font-bold text-lg text-slate-900 group-hover:text-blue-600 transition-colors">{item.title}</h3>
              <p className="mt-2 text-sm text-slate-500 line-clamp-2">
                {item.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
