
import React, { useState } from 'react';
import { MenuIcon, XIcon } from './Icons';

export const Header: React.FC = () => {
  const [mobileOpen, setMobileOpen] = useState(false);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'Serviços', href: '#servicos' },
    { name: 'Planos', href: '#planos' },
    { name: 'Cases', href: '#cases' },
    { name: 'Sobre', href: '#sobre' },
    { name: 'Contato', href: '#contato' },
  ];

  const handleScroll = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault(); // Impede o navegador de tentar "sair" da página
    const targetId = href.replace('#', '');
    const element = document.getElementById(targetId);
    
    if (element) {
      // Ajuste de offset para o header fixo (aprox 80px)
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
  
      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
      
      setMobileOpen(false); // Fecha o menu mobile se estiver aberto
    }
  };

  return (
    <header className="sticky top-0 z-[100] backdrop-blur-md bg-white/80 border-b border-slate-200 shadow-sm transition-all duration-300">
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-4 cursor-default">
          <div className="w-10 h-10 rounded-lg bg-slate-900 flex items-center justify-center text-white font-bold shadow-lg shadow-slate-900/20">
            SR
          </div>
          <div>
            <div className="font-bold text-slate-900 leading-tight">Social Refinement</div>
            <div className="text-[10px] uppercase tracking-wider text-slate-500 font-medium">Autoridade Digital</div>
          </div>
        </div>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href} 
              onClick={(e) => handleScroll(e, link.href)}
              className="hover:text-slate-900 hover:underline decoration-slate-900/20 underline-offset-4 transition-colors cursor-pointer"
            >
              {link.name}
            </a>
          ))}
          <a 
            href="#planos" 
            onClick={(e) => handleScroll(e, '#planos')}
            className="ml-2 px-5 py-2.5 rounded-full bg-slate-100 border border-slate-200 text-slate-900 hover:bg-slate-200 hover:shadow-sm transition-all text-xs font-semibold uppercase tracking-wide cursor-pointer"
          >
            Quero minha reestruturação
          </a>
        </nav>

        {/* Mobile Toggle */}
        <div className="md:hidden">
          <button 
            onClick={() => setMobileOpen(!mobileOpen)} 
            className="p-2 rounded-md hover:bg-slate-100 transition-colors"
            aria-label="Menu"
          >
            {mobileOpen ? <XIcon className="h-6 w-6 text-slate-900" /> : <MenuIcon className="h-6 w-6 text-slate-900" />}
          </button>
        </div>
      </div>

      {/* Mobile Nav Menu */}
      {mobileOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-white border-b border-slate-100 shadow-xl py-4 animate-in fade-in slide-in-from-top-4 duration-200">
          <div className="px-6 flex flex-col gap-2">
            {navLinks.map((link) => (
              <a 
                key={link.name} 
                href={link.href} 
                onClick={(e) => handleScroll(e, link.href)} 
                className="py-3 text-slate-600 font-medium border-b border-slate-50 last:border-0 hover:text-slate-900 hover:bg-slate-50 px-2 rounded-md transition-colors cursor-pointer"
              >
                {link.name}
              </a>
            ))}
            <a 
              href="#planos"
              onClick={(e) => handleScroll(e, '#planos')}
              className="mt-4 w-full text-center px-4 py-3 rounded-lg bg-slate-900 text-white font-medium shadow-md cursor-pointer"
            >
              Quero minha reestruturação
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
