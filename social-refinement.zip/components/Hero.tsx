
import React from 'react';
import { CameraIcon, ArrowRightIcon } from './Icons';
import { AppConfig } from '../config';

interface HeroProps {
  onCtaClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onCtaClick }) => {
  return (
    <section id="home" className="max-w-6xl mx-auto px-6 py-16 lg:py-24 relative overflow-hidden">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
        {/* Content Column - Added z-20 to ensure it sits on top of any floating elements */}
        <div className="relative z-20">
          <div className="inline-block px-3 py-1 bg-slate-100 text-slate-600 rounded-full text-xs font-semibold uppercase tracking-wider mb-6">
            Estratégia & Design
          </div>
          <h1 className="text-4xl lg:text-6xl font-extrabold leading-[1.1] text-slate-900 tracking-tight">
            Transforme seu perfil em <span className="text-transparent bg-clip-text bg-gradient-to-r from-slate-900 to-slate-600">autoridade digital</span>.
          </h1>
          <p className="mt-6 text-slate-600 text-lg leading-relaxed max-w-lg">
            Combinamos minimalismo, estratégia de conteúdo e design premium para inspirar confiança imediata no seu público.
          </p>

          <div className="mt-8 flex flex-wrap gap-4">
            <button 
              onClick={onCtaClick} 
              className="cursor-pointer inline-flex items-center gap-2 px-8 py-4 rounded-full bg-slate-900 text-white font-semibold shadow-lg shadow-slate-900/20 hover:bg-slate-800 hover:scale-105 transition-all duration-300 relative z-30"
            >
              Iniciar Transformação
              <ArrowRightIcon className="w-4 h-4" />
            </button>
            <a 
              href="#servicos" 
              className="cursor-pointer inline-flex items-center gap-2 px-6 py-4 rounded-full border border-slate-200 text-slate-700 font-medium hover:bg-slate-50 transition-colors relative z-30"
            >
              Ver Soluções
            </a>
          </div>

          <div className="mt-10 grid grid-cols-2 gap-4 text-xs font-medium text-slate-500">
            <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg border border-slate-100">
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
              Para Médicos & Advogados
            </div>
            <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg border border-slate-100">
              <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></span>
              Para Empresários & Experts
            </div>
          </div>

          <div className="mt-10 flex items-center gap-4 border-t border-slate-100 pt-6">
            <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-slate-200 to-slate-100 flex items-center justify-center border border-white shadow-sm">
               <CameraIcon className="w-5 h-5 text-slate-400" />
            </div>
            <div>
              <div className="text-sm font-semibold text-slate-900">Junte-se a líderes de mercado</div>
              <div className="text-xs text-slate-500">Mais de 200 perfis reestruturados este ano.</div>
            </div>
          </div>
        </div>

        {/* Visual Column - Added pointer-events-none to decorative parts to prevent blocking clicks */}
        <div className="relative lg:h-[600px] flex items-center justify-center z-10">
          {/* Decorative backgrounds */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-gradient-to-tr from-slate-100 to-transparent rounded-full blur-3xl -z-10 opacity-60 animate-pulse pointer-events-none" style={{ animationDuration: '4s' }}></div>
          
          {/* Main Hero Image / Mockup Card */}
          <div className="relative w-full max-w-sm aspect-[4/5] rounded-3xl overflow-hidden flex flex-col z-0 animate-float-delayed shadow-2xl border border-slate-100 pointer-events-auto">
             <img 
               src={AppConfig.images.hero} 
               alt="Social Refinement Mockup" 
               className="w-full h-full object-cover"
             />
          </div>

          {/* Floating elements - Independent animation */}
          <div className="absolute top-20 right-4 lg:right-0 z-10 bg-white p-4 rounded-xl shadow-xl border border-slate-100 animate-float pointer-events-none">
            <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center text-green-600 font-bold text-xs">A+</div>
                <div className="text-xs font-semibold text-slate-700">Autoridade Elevada</div>
            </div>
          </div>

          <div className="absolute bottom-40 left-4 lg:-left-6 z-10 bg-white p-4 rounded-xl shadow-xl border border-slate-100 animate-float pointer-events-none">
            <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold text-xs">✓</div>
                <div className="text-xs font-semibold text-slate-700">Design Validado</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
