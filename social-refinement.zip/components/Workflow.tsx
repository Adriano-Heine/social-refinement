import React from 'react';

export const Workflow: React.FC = () => {
  const steps = [
    { num: '01', title: 'Diagnóstico', desc: 'Analisamos seu perfil atual e identificamos as lacunas de autoridade.' },
    { num: '02', title: 'Conceito', desc: 'Desenvolvemos a linha visual e a narrativa que vai guiar sua marca.' },
    { num: '03', title: 'Produção', desc: 'Criação dos assets, sites e templates com aprovação etapa por etapa.' },
    { num: '04', title: 'Handoff', desc: 'Entrega dos arquivos e treinamento rápido para sua equipe assumir.' },
  ];

  return (
    <section className="py-20 px-6 max-w-6xl mx-auto">
      <div className="text-center mb-16">
        <h2 className="text-3xl font-bold text-slate-900">Como trabalhamos</h2>
        <p className="mt-4 text-slate-600">Um processo linear e sem surpresas.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {steps.map((step, index) => (
          <div key={step.num} className="relative">
             {/* Connector Line */}
            {index < steps.length - 1 && (
              <div className="hidden lg:block absolute top-8 left-1/2 w-full h-[1px] bg-slate-200 -z-10"></div>
            )}
            
            <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow h-full flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-slate-50 text-slate-300 font-bold text-xl flex items-center justify-center mb-4 border border-slate-100">
                {step.num}
              </div>
              <h4 className="text-lg font-bold text-slate-900 mb-2">{step.title}</h4>
              <p className="text-sm text-slate-500 leading-relaxed">{step.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
