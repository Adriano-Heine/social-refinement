import React from 'react';
import { PlanDetails, PlanType } from '../types';
import { CheckIcon } from './Icons';

interface PlansProps {
  onSelectPlan: (plan: PlanType) => void;
  selectedPlan: PlanType | null;
}

export const Plans: React.FC<PlansProps> = ({ onSelectPlan, selectedPlan }) => {
  const plans: PlanDetails[] = [
    {
      id: 'essencial',
      name: 'Essencial',
      description: 'Para profissionais liberais iniciando o posicionamento.',
      features: ['Mini-site para bio (1 página)', '5 templates de post (Feed)', 'Guia de uso básico', 'Entrega em 7 dias úteis', 'Suporte via WhatsApp'],
    },
    {
      id: 'profissional',
      name: 'Profissional',
      description: 'Para empresários que buscam crescimento acelerado.',
      recommended: true,
      features: ['Tudo do Essencial', '10 templates (Feed + Stories)', 'Cartão digital interativo', '1 sessão estratégica de conteúdo', 'Otimização de biografia', 'Entrega em 10 dias úteis'],
    },
    {
      id: 'autoridade',
      name: 'Autoridade',
      description: 'Posicionamento de liderança para grandes players.',
      features: ['Tudo do Profissional', 'Site completo (Landing Page)', 'Assessoria visual por 30 dias', 'Análise de métricas mensal', 'Brandbook completo', 'Prioridade na entrega'],
    },
  ];

  return (
    <section id="planos" className="py-24 bg-slate-900 text-white">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold">Investimento em Autoridade</h2>
          <p className="mt-4 text-slate-400 text-lg">Escolha o nível de refinamento que seu momento de carreira exige.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan) => (
            <div 
              key={plan.id} 
              className={`
                relative flex flex-col rounded-2xl transition-all duration-300 group
                ${plan.recommended 
                  ? 'scale-105 z-10' 
                  : ''
                }
              `}
            >
              {/* Badge lives OUTSIDE the overflow-hidden container */}
              {plan.recommended && (
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 px-4 py-1 bg-white text-slate-900 text-xs font-bold uppercase tracking-wider rounded-full shadow-lg z-20 whitespace-nowrap">
                  Mais Escolhido
                </div>
              )}

              {/* Inner Container for content with overflow hidden (for shine effect) */}
              <div className={`
                flex-1 flex flex-col p-8 rounded-2xl overflow-hidden relative
                ${plan.recommended 
                  ? 'bg-slate-800 border-2 border-slate-600 shadow-2xl' 
                  : 'bg-slate-850 border border-slate-700 hover:border-slate-600'
                }
              `}>
                
                {plan.recommended && (
                  /* Shine Effect contained inside */
                  <div className="absolute inset-0 z-0 pointer-events-none">
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full animate-shine"></div>
                  </div>
                )}

                <div className="mb-6 relative z-10">
                  <h3 className="text-2xl font-bold">{plan.name}</h3>
                  <p className="mt-2 text-slate-400 text-sm h-10">{plan.description}</p>
                </div>

                <ul className="flex-1 space-y-4 mb-8 relative z-10">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-start gap-3 text-sm text-slate-300">
                      <CheckIcon className="w-5 h-5 text-white shrink-0" />
                      <span className="leading-tight">{feature}</span>
                    </li>
                  ))}
                </ul>

                <button 
                  onClick={() => onSelectPlan(plan.id)}
                  className={`
                    w-full py-4 rounded-xl font-semibold transition-all relative z-10
                    ${selectedPlan === plan.id 
                      ? 'bg-green-500 text-white ring-2 ring-green-300 ring-offset-2 ring-offset-slate-900' 
                      : plan.recommended 
                        ? 'bg-white text-slate-900 hover:bg-slate-200' 
                        : 'bg-slate-700 text-white hover:bg-slate-600'
                    }
                  `}
                >
                  {selectedPlan === plan.id ? 'Plano Selecionado' : `Selecionar ${plan.name}`}
                </button>
              </div>
            </div>
          ))}
        </div>
        
        {selectedPlan && (
           <div className="mt-12 p-6 bg-slate-800 rounded-xl border border-slate-700 flex flex-col md:flex-row items-center justify-between gap-4 animate-in fade-in slide-in-from-bottom-4">
             <div>
                <p className="text-green-400 font-semibold mb-1">Ótima escolha!</p>
                <p className="text-slate-300 text-sm">Você selecionou o plano <strong className="text-white capitalize">{selectedPlan}</strong>. Preencha o formulário abaixo para recebermos seu interesse.</p>
             </div>
             <a href="#contato" className="px-6 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg text-sm font-semibold transition-colors">
               Ir para Contato
             </a>
           </div>
        )}
      </div>
    </section>
  );
};