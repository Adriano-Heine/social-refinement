
import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Services } from './components/Services';
import { Workflow } from './components/Workflow';
import { Plans } from './components/Plans';
import { Cases } from './components/Cases';
import { About } from './components/About';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { PlanType } from './types';

function App() {
  const [selectedPlan, setSelectedPlan] = useState<PlanType | null>(null);

  const handleSelectPlan = (plan: PlanType) => {
    setSelectedPlan(plan);
    const contactSection = document.getElementById('contato');
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToPlans = () => {
    const plansSection = document.getElementById('planos');
    if (plansSection) {
      plansSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    // Key prop forces a full remount when changed, ensuring clean state
    <div key="v3-final-fix" className="min-h-screen bg-white text-slate-900 antialiased font-sans selection:bg-slate-900 selection:text-white">
      <Header />
      <main>
        <Hero onCtaClick={scrollToPlans} />
        <Services />
        <Workflow />
        <Plans onSelectPlan={handleSelectPlan} selectedPlan={selectedPlan} />
        <Cases />
        <About />
        <Contact selectedPlan={selectedPlan} />
      </main>
      <Footer />
    </div>
  );
}

export default App;