

export const AppConfig = {
  // Email para onde os formulários serão enviados (FormSubmit)
  // IMPORTANTE: Na primeira vez que testar, você receberá um email do FormSubmit pedindo para confirmar.
  formEmail: "jorgeheine@gmail.com", 

  // URL do Mailchimp (Extraído do código que você enviou)
  // Se estiver preenchido, o rodapé usará o Mailchimp. Se estiver vazio "", usará o FormSubmit acima.
  newsletterAction: "https://gmail.us12.list-manage.com/subscribe/post?u=f6148218e0dad16a946435ab7&id=f46680f6bf&f_id=0098e4e0f0",

  // Configuração de Imagens
  // DICA: Para melhor visualização, tente usar imagens com as proporções sugeridas abaixo.
  images: {
    // Imagem da Primeira Dobra (Hero) - Sugestão: Vertical (Portrait) ou Mockup de Celular
    // Substitua este link pelo seu mockup de celular com fundo transparente ou foto de perfil
    hero: "https://res.cloudinary.com/dfbsag282/image/upload/v1764173883/Bio_Plus_amdfhf.png",

    // Imagem da seção "Sobre" (Equipe ou Escritório) - Sugestão: Quadrada ou Retangular
    // Usando uma foto de um escritório minimalista e clean
    about: "https://res.cloudinary.com/dfbsag282/image/upload/v1764176879/Studio_clean_kqee41.png",
    
    // Imagens dos Cases (Adicione quantas URLs quiser aqui) - Sugestão: Retangular (4:3 ou 800x600px)
    cases: [
      {
        // Advocacia: Foto sóbria, terno, ambiente corporativo escuro
        url: "https://res.cloudinary.com/dfbsag282/image/upload/v1764173741/Bio_advogado_vtnfsg.png",
        title: "Dr. Roberto Mendes",
        category: "Advocacia",
        description: "Aumentamos a percepção de valor dos honorários através de uma identidade visual sóbria."
      },
      {
        // Dermatologia: Foto clara, clean, tons de pele e branco
        url: "https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=800&q=80",
        title: "Dra. Juliana Paes",
        category: "Dermatologia",
        description: "Rebranding completo focado em elegância e procedimentos de alto ticket."
      },
      {
        // Consultoria: Foto moderna, arquitetura, vidro, reuniões
        url: "https://images.unsplash.com/photo-1600880292203-757bb62b4baf?auto=format&fit=crop&w=800&q=80",
        title: "Marcos & Associados",
        category: "Consultoria",
        description: "Criação de site institucional e padronização de materiais comerciais."
      }
    ]
  },

  // Dados de Contato e Redes Sociais
  contact: {
    email: "jorgeheine@gmail.com",
    phone: "+55 (71) 99126-1474",
    location: "Salvador, BA — Brasil",
    whatsappLink: "https://wa.me/5571991261474", // Link direto para o WhatsApp
    instagramLink: "https://www.instagram.com/_artesdigitais",
    linkedinLink: "https://www.linkedin.com/in/adriano-jorge/"
  },

  // Configurações Gerais
  companyName: "Social Refinement",
  year: new Date().getFullYear()
};