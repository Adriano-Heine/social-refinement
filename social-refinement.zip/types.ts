import React from 'react';

export type PlanType = 'essencial' | 'profissional' | 'autoridade';

export interface PlanDetails {
  id: PlanType;
  name: string;
  description: string;
  features: string[];
  recommended?: boolean;
}

export interface ServiceItem {
  title: string;
  desc: string;
  icon?: React.ReactNode;
}